

<?php


include("simple_html_dom.php");


$arrContextOptions=array(
    "ssl"=>array(
        "verify_peer"=>false,
        "verify_peer_name"=>false,
    ),
);  


if(isset($_POST['submit']))
{
$url = $_REQUEST['actor'] ;
if (!empty($url)) {
  $html = file_get_html($url);
  if (!empty($html)) {
    $content = $html->find('<body>', 0)->outertext;
   $list='';
  $list.='<div class="col-md-12">
<form action="" method="post">
<div class="col-md-12">
<Label>Actor</label>
  <textarea rows="30" style="width:100%" id="area1" >'.$content.'</textarea>
</div>
<div class="col-md-12" style="float:left">
 </form> 
</div>
</div>';
echo $list;
  }
}


} 
  
  


?>

 
<!DOCTYPE html>
<html>
<head>
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

</head>
<body>

<h2>Webscrapper plugin</h2>
<div class="container">
<form action="" method="post">
 <div class="form-group">
  <input type="text" class="form-control" name="actor" placeholder="Enter your link">
   </div>
   
  <input type="submit" class="btn btn-default" value="submit" name="submit">
 </form> 
 </div>
<br>


<script type="text/javascript" src="http://js.nicedit.com/nicEdit-latest.js"></script>
<script type="text/javascript">
        bkLib.onDomLoaded(function() { nicEditors.allTextAreas() }); // convert all text areas to rich text editor on that page

        bkLib.onDomLoaded(function() {
             new nicEditor().panelInstance('area1');
        }); 
		
		</script>

</body>
</html>
